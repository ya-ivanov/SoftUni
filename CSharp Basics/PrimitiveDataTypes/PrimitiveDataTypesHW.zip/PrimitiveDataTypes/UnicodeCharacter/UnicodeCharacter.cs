﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnicodeCharacter
{
    class UnicodeCharacter
    {
        static void Main()
        {
            char myChar = '\u0048';
            Console.WriteLine(myChar);
        }
    }
}
