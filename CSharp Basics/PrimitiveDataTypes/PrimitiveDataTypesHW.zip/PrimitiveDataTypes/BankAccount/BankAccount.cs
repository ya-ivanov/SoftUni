﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankAccount
{
    class BankAccount
    {
        static void Main()
        {
            string firstName = "Xxxxx";
            string middleName = "Xxxxxxxxx";
            string lastName = "Xxxxxx";
            string holderName = firstName + " " + middleName + " " + lastName;
            decimal moneyBalance;
            string bankName;
            string IBAN;
            ulong creditCard1Nbr;
            ulong creditCar2Nbr;
            ulong creditCard3Nbr;
        }
    }
}
