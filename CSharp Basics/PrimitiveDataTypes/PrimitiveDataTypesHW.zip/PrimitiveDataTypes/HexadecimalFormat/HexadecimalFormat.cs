﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HexadecimalFormat
{
    class HexadecimalFormat
    {
        static void Main()
        {
            int num254 = 0xFE;
            Console.WriteLine(num254);
        }
    }
}
