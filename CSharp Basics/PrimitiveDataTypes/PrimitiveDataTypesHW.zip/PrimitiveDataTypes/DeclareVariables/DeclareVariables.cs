﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeclareVariables
{
    class DeclareVariables
    {
        static void Main()
        {
            sbyte sByteNum = -115;
            byte byteNum = 97;
            ushort ushortNum = 52130;
            short shortNum = -10000;
            int integer = 4825932;
        }
    }
}
