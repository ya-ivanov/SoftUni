﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrintMyName
{
    class PrintMyName
    {
        static void Main()
        {
            Console.WriteLine("Hi. My name is Yavor");
        }
    }
}
