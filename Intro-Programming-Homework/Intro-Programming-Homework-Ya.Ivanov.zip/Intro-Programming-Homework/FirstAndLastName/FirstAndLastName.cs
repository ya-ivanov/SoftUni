﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirstAndLastName
{
    class FirstAndLastName
    {
        static void Main()
        {
            Console.WriteLine("{0}", "Yavor");
            Console.WriteLine("Ivanov");
        }
    }
}
