﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SquareRoot
{
    class SquareRoot
    {
        static void Main()
        {
            Console.WriteLine("Square root of '12345': {0}", Math.Sqrt(12345));
        }
    }
}
