﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloCSharp
{
    class HelloCSharp
    {
        static void Main()
        {
            Console.WriteLine("{0} \n{1}", "Hello CSharp", "Hello C#");
            
        }
    }
}
