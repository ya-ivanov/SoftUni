﻿using System;
class Matrix
{
    static void Main()
    {
        int r = int.Parse(Console.ReadLine());
        int c = int.Parse(Console.ReadLine());
        
        for (int i = 0; i < r; i++)
        {
            for (int g = 0; g < c; g++)
                Console.Write("aaa ");
                
            Console.WriteLine();
        }
    }
}