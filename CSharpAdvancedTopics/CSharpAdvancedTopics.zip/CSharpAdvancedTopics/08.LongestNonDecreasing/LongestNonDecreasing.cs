﻿using System;
using System.Collections.Generic;

class LongestNonDecreasing
{
    static void Main()
    {
       
    }
}